package NewPerseanRepublic;

import NewPerseanRepublic.hullmods.*;
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
public class ModPlugin {
    public static final String modId = "NPR";
}
