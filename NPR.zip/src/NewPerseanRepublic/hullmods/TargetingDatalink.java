package NewPerseanRepublic.hullmods;

import NewPerseanRepublic.Utils;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;
import java.util.Iterator;

public class TargetingDatalink extends BaseHullMod {
    public static float WEAPON_FLUX_MULT1 = 0.2F;
    public static float WEAPON_FIRE_RATE_MULT1 = 0.2F;
    public static float WEAPON_DAMAGE_MULT1 = 0.2F;
    public static float WEAPON_RANGE_MOD1 = 0.5f;
    public static float WEAPON_RANGE_MOD2 = 0.2f;
    public static float MIN_EFFECTIVE_RANGE = 760f;
    public static float MAX_EFFECTIVE_RANGE = 560f;

    public void advanceInCombat(ShipAPI ship, float amount) {
        if (!ship.isAlive()) {
            return;
    }
        MutableShipStatsAPI stats = ship.getMutableStats();
        String key = "targeting_datalink_" + ship.getId();
        Utils.TargetingDatalinkData data = (Utils.TargetingDatalinkData) Global.getCombatEngine().getCustomData().get(key);
        if (data == null) {
            data = new Utils.TargetingDatalinkData();
            Global.getCombatEngine().getCustomData().put(key, data);
        }
        data.interval.advance(amount);
        if (data.interval.intervalElapsed() || ship == Global.getCombatEngine().getPlayerShip()) {
            float minEffectRange = MIN_EFFECTIVE_RANGE;
            float maxEffectRange = MAX_EFFECTIVE_RANGE;

            float checkSize = (minEffectRange + maxEffectRange + ship.getCollisionRadius() + 300f) * 2f;
            float bestMag = 0f;

            for (Iterator<Object> itr = Global.getCombatEngine().getShipGrid().getCheckIterator(ship.getLocation(), checkSize, checkSize); itr.hasNext(); ) {
                Object next = itr.next();

                if (!(next instanceof ShipAPI)) {
                    continue;
                }

                ShipAPI other = (ShipAPI) next;

                if (other.isFighter()) {
                    continue;
                }
                if (ship == other) {
                    continue;
                }
                if (other.getOwner() != ship.getOwner()) {
                    continue;
                }
                if (other.isHulk()) {
                    continue;
                }
                if (!Utils.hasTargetingCore(other.getVariant())) {
                    continue;
                }

                float radiusSum = (ship.getShieldRadiusEvenIfNoShield() + other.getShieldRadiusEvenIfNoShield()) * 0.75f;
                float dist = Misc.getDistance(ship.getShieldCenterEvenIfNoShield(), other.getShieldCenterEvenIfNoShield()) - radiusSum;

                float mag = 0f;
                if (dist < minEffectRange) {
                    mag = 2f;
                } else if (dist < minEffectRange + maxEffectRange) {
                    mag = 2f - (dist - minEffectRange) / maxEffectRange;
                }

                if (mag > bestMag) {
                    bestMag = mag;
                }

                data.mag = bestMag;
            }

            if (ship.getHullSize().ordinal() <= 2) {
                stats.getEnergyWeaponDamageMult().modifyMult(this.spec.getId(), 1.0F + WEAPON_DAMAGE_MULT1 * data.mag);
                stats.getBallisticWeaponDamageMult().modifyMult(this.spec.getId(), 1.0F + WEAPON_DAMAGE_MULT1 * data.mag);
                stats.getEnergyWeaponRangeBonus().modifyMult(this.spec.getId(), 1.0f + WEAPON_RANGE_MOD1 * data.mag);
                stats.getBallisticWeaponRangeBonus().modifyMult(this.spec.getId(), 1.0f + WEAPON_RANGE_MOD1 * data.mag);
            } else {
                stats.getEnergyWeaponFluxCostMod().modifyMult(this.spec.getId(), 1.0F - WEAPON_FLUX_MULT1 * data.mag);
                stats.getEnergyRoFMult().modifyMult(this.spec.getId(), 1.0F + WEAPON_FIRE_RATE_MULT1 * data.mag);
                stats.getBallisticWeaponFluxCostMod().modifyMult(this.spec.getId(), 1.0F - WEAPON_FLUX_MULT1 * data.mag);
                stats.getBallisticRoFMult().modifyMult(this.spec.getId(), 1.0F + WEAPON_FIRE_RATE_MULT1 * data.mag);
                stats.getEnergyWeaponRangeBonus().modifyMult(this.spec.getId(), 1.0f + WEAPON_RANGE_MOD2 * data.mag);
                stats.getBallisticWeaponRangeBonus().modifyMult(this.spec.getId(), 1.0f + WEAPON_RANGE_MOD2 * data.mag);
            }
        }

        if (ship == Global.getCombatEngine().getPlayerShip()) {
            String icon = Global.getSettings().getSpriteName("ui", "icon_tactical_escort_package");
            if (data.mag > 0.005f) {
                Global.getCombatEngine().maintainStatusForPlayerShip(key, icon, "Targeting Datalink", Math.round(data.mag * 50f) + "% telemetry quality", false);
            } else {
                Global.getCombatEngine().maintainStatusForPlayerShip(key, icon, "Targeting Datalink", "no connection", true);
            }
        }
    }
    @Override
    public void addPostDescriptionSection(TooltipMakerAPI tooltip, HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
        float pad = 3f;
        float oPad = 10f;
        Color b = Misc.getHighlightColor();
        Color good = Misc.getPositiveHighlightColor();

        tooltip.setBulletedListMode("");
        tooltip.addPara("If a %s has a %s and is within %s:", oPad, b, "Friendly ship", "Targeting Core/Unit", 1000 + "su");
        tooltip.setBulletedListMode("  ^ ");
        tooltip.addPara("Increases the range and non-missile weapons fire rate by %s if the ship is a Cruiser/Capital ship", pad, good, Math.round(WEAPON_RANGE_MOD2 * 100f) + "%");
        tooltip.addPara("Increases the range of non-missile weapons by %s and 20 percent bonus damage of weapons if the ship is a Frigate/Destroyer", pad, good, Math.round(WEAPON_RANGE_MOD1 * 100f) + "%");
        tooltip.setBulletedListMode(null);
    }
}
