package NewPerseanRepublic.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class DAITU extends BaseHullMod {



    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return !ship.getVariant().getHullMods().contains("dedicated_targeting_core") &&
                !ship.getVariant().getHullMods().contains(HullMods.DISTRIBUTED_FIRE_CONTROL) &&
                !ship.getVariant().getHullMods().contains("advancedcore");
    }

    public String getUnapplicableReason(ShipAPI ship) {
        if (ship.getVariant().getHullMods().contains("dedicated_targeting_core")) {
            return "Incompatible with Dedicated Targeting Core";
        }
        if (ship.getVariant().getHullMods().contains("advancedcore")) {
            return "Incompatible with Advanced Targeting Core";
        }
        if (ship.getVariant().getHullMods().contains(HullMods.DISTRIBUTED_FIRE_CONTROL)) {
            return "Incompatible with Distributed Fire Control";
        }
        return null;
    }

    public static float RANGE_BONUS = 60f;
    public static float PD_MINUS = 20f;

    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) return "" + (int)Math.round(RANGE_BONUS) + "%";
        if (index == 1) return "" + (int)Math.round(RANGE_BONUS - PD_MINUS) + "%";
        return null;
    }


    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getBallisticWeaponRangeBonus().modifyPercent(id, RANGE_BONUS);
        stats.getEnergyWeaponRangeBonus().modifyPercent(id, RANGE_BONUS);

        stats.getNonBeamPDWeaponRangeBonus().modifyPercent(id, -PD_MINUS);
        stats.getBeamPDWeaponRangeBonus().modifyPercent(id, -PD_MINUS);
    }

}
