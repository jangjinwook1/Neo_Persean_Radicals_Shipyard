package NewPerseanRepublic;

public class ids {
    public static final String TARGETING_DATALINK = "NPR_targeting_datalink";
}
